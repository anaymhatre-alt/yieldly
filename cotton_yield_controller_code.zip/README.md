# Kharif Cotton Fuzzy Yield Controller

A Python/Streamlit demonstration app that estimates cotton yield from cultivated area, Kharif-season rainfall, and supplemental irrigation. The inference engine is a Mamdani fuzzy system with triangular membership functions, a 3×3 rule base, max aggregation, and centroid defuzzification.

## Run the app

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Use rainfall data

Select **Upload rainfall CSV** and upload daily or monthly rainfall observations. The app filters records by year, optional location, and the selected season months, then sums rainfall in millimetres before passing that seasonal total to the fuzzy controller. The default month window is June–September; adjust it to match the local cotton calendar. Choose **Enter rainfall manually** if you do not have a dataset.

Accepted CSV layouts:

```csv
date,rainfall_mm,location
2025-06-01,4.2,Akola
2025-06-02,0.0,Akola
```

or:

```csv
year,month,rainfall_mm,district
2025,6,4.2,Akola
2025,6,0.0,Akola
```

The app also accepts a monthly wide table with a `year` column and month columns such as `Jan`, `Feb`, …, `Dec`; it converts those monthly values into season records before filtering.

The rainfall field can also be named `rainfall`, `daily_rainfall_mm`, `monthly_rainfall_mm`, `actual_rainfall`, or `precipitation_mm`. A location field is optional; recognized names include `location`, `district`, `station`, and `subdivision`. The included `rainfall_data_template.csv` contains the expected daily-data column headings and no fabricated observations.

India's Open Government Data portal lists district-wise and other rainfall resources at [data.gov.in rainfall catalog](https://data.gov.in/catalog/rainfall). Use a dataset for the relevant district or station and check its units and date coverage before upload. The app does not fetch external datasets automatically.

## Model notes

The default cotton profile values and fuzzy rules are illustrative, not locally calibrated agronomic recommendations. The rules permit irrigation to offset low rainfall and lower estimated yield when both rainfall and irrigation are very high. The model does not account for soil, temperature, cotton variety, pests, crop stage, or spatial variation. Calibrate and validate against local historical records before using estimates for decisions.

## Project files

- `app.py` — Streamlit interface, Kharif month selection, CSV parsing, and seasonal rainfall aggregation.
- `fuzzy_controller.py` — Mamdani fuzzy inference and yield calculations.
- `rainfall_data_template.csv` — empty CSV header template for daily rainfall records.
- `requirements.txt` — Python dependency list.
- `Cotton_Fuzzy_Logic_Controller_Report.docx` — project report.
