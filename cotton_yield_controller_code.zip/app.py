import calendar

import pandas as pd
import streamlit as st

from fuzzy_controller import CottonProfile, estimate_cotton_yield


st.set_page_config(page_title="Kharif Cotton Yield Controller", page_icon="🌱", layout="centered")
st.title("🌱 Kharif Cotton Yield Estimator")
st.write("Estimate cotton yield using cultivated area, Kharif rainfall, and supplemental irrigation.")
st.info("This educational fuzzy-logic demo uses illustrative cotton settings and rules. Calibrate it with local crop data before using estimates for decisions.")


def normalized_column(name):
    return "".join(ch.lower() for ch in str(name) if ch.isalnum())


def find_column(frame, aliases):
    columns = {normalized_column(name): name for name in frame.columns}
    for alias in aliases:
        if alias in columns:
            return columns[alias]
    return None


def prepare_rainfall_csv(frame):
    """Accept daily/monthly CSVs in tidy or year-by-month layout."""
    date_col = find_column(frame, ["date", "datetime", "observationdate", "recorddate"])
    year_col = find_column(frame, ["year", "yr"])
    month_col = find_column(frame, ["month", "monthnumber", "mnth"])
    rain_col = find_column(frame, [
        "rainfallmm", "rainfall", "dailyrainfallmm", "monthlyrainfallmm",
        "actualrainfall", "actualrainfallmm", "rainfallactual", "precipitationmm",
    ])
    location_col = find_column(frame, ["location", "district", "station", "subdivision", "meteorologicalsubdivision"])
    year_month_cols = {}
    for col in frame.columns:
        key = normalized_column(col)
        for month_number in range(1, 13):
            if key in {normalized_column(calendar.month_name[month_number]), normalized_column(calendar.month_abbr[month_number])}:
                year_month_cols[col] = month_number
                break

    if rain_col is None:
        if year_col and year_month_cols:
            id_columns = [year_col] + ([location_col] if location_col else [])
            melted = frame.melt(id_vars=id_columns, value_vars=list(year_month_cols), var_name="_month_name", value_name="rainfall_mm")
            melted["_month"] = melted["_month_name"].map(year_month_cols)
            dates = pd.to_datetime({
                "year": pd.to_numeric(melted[year_col], errors="coerce"),
                "month": melted["_month"],
                "day": 1,
            }, errors="coerce")
            result = pd.DataFrame({"date": dates, "rainfall_mm": pd.to_numeric(melted["rainfall_mm"], errors="coerce")})
            if location_col:
                result["location"] = melted[location_col].astype("string").str.strip()
            result = result.dropna(subset=["date", "rainfall_mm"])
            if result.empty:
                raise ValueError("No usable year and monthly rainfall values were found in the CSV.")
            return result
        raise ValueError("Could not identify rainfall values. Use rainfall_mm, rainfall, or a Year column with Jan–Dec columns.")
    if date_col:
        dates = pd.to_datetime(frame[date_col], errors="coerce", dayfirst=True)
    elif year_col and month_col:
        year = pd.to_numeric(frame[year_col], errors="coerce")
        month = pd.to_numeric(frame[month_col], errors="coerce")
        if month.isna().any():
            month_names = {normalized_column(calendar.month_name[m]): m for m in range(1, 13)}
            month_names.update({normalized_column(calendar.month_abbr[m]): m for m in range(1, 13)})
            month = month.fillna(frame[month_col].map(lambda val: month_names.get(normalized_column(val))))
        dates = pd.to_datetime({"year": year, "month": month, "day": 1}, errors="coerce")
    else:
        raise ValueError("Add a Date column, or both Year and Month columns.")

    result = pd.DataFrame({
        "date": dates,
        "rainfall_mm": pd.to_numeric(frame[rain_col], errors="coerce"),
    })
    if location_col:
        result["location"] = frame[location_col].astype("string").str.strip()
    result = result.dropna(subset=["date", "rainfall_mm"])
    if result.empty:
        raise ValueError("No usable date and rainfall rows were found in the CSV.")
    return result


with st.sidebar:
    st.header("Cotton settings")
    potential = st.number_input("Potential cotton yield (tonnes/hectare)", min_value=0.1, value=2.5, step=0.1)
    optimum = st.number_input("Optimal Kharif rainfall reference (mm)", min_value=1.0, value=700.0, step=25.0)
    adequate_irrigation = st.number_input("Adequate supplemental irrigation reference (mm)", min_value=1.0, value=300.0, step=25.0)
    st.caption("Illustrative defaults. Adjust using a trusted local source or dataset.")

st.subheader("Kharif rainfall")
season_left, season_right = st.columns(2)
with season_left:
    start_month = st.selectbox("Season starts", range(1, 13), index=5, format_func=lambda m: calendar.month_name[m])
with season_right:
    end_options = list(range(start_month, 13))
    default_end = 9 if 9 in end_options else end_options[-1]
    end_month = st.selectbox("Season ends", end_options, index=end_options.index(default_end), format_func=lambda m: calendar.month_name[m])
st.caption("Default window is June–September. Set the months to match the local cotton calendar.")

rainfall_source = st.radio("Rainfall source", ["Upload rainfall CSV", "Enter rainfall manually"], horizontal=True)
rainfall_mm = None
rainfall_summary = None

if rainfall_source == "Upload rainfall CSV":
    uploaded = st.file_uploader("Upload daily or monthly rainfall data (.csv)", type=["csv"])
    st.caption("Accepted: Date + rainfall_mm; Year + Month + rainfall_mm; or Year with Jan–Dec columns. Optional location column: District, Location, Station, or Subdivision.")
    st.markdown("Official dataset catalog: [India rainfall datasets on data.gov.in](https://data.gov.in/catalog/rainfall)")
    if uploaded is not None:
        try:
            uploaded.seek(0)
            raw = pd.read_csv(uploaded)
            rainfall_data = prepare_rainfall_csv(raw)
            years = sorted(rainfall_data["date"].dt.year.unique().tolist(), reverse=True)
            selected_year = st.selectbox("Year", years)
            selected_location = None
            if "location" in rainfall_data:
                locations = sorted(rainfall_data["location"].dropna().unique().tolist())
                if locations:
                    selected_location = st.selectbox("Location", locations)
            selected = rainfall_data[
                (rainfall_data["date"].dt.year == selected_year)
                & rainfall_data["date"].dt.month.between(start_month, end_month)
            ]
            if selected_location is not None:
                selected = selected[selected["location"] == selected_location]
            if selected.empty:
                st.warning("No rainfall rows match the selected year, location, and Kharif months.")
            else:
                rainfall_mm = float(selected["rainfall_mm"].sum())
                place = f" for {selected_location}" if selected_location else ""
                rainfall_summary = f"{rainfall_mm:.1f} mm from {len(selected)} records{place}, {selected_year}"
                st.metric("Accumulated Kharif rainfall", f"{rainfall_mm:.1f} mm")
                st.caption(f"Using {len(selected)} dataset records{place} for {calendar.month_name[start_month]}–{calendar.month_name[end_month]} {selected_year}.")
        except (ValueError, pd.errors.ParserError, UnicodeDecodeError) as exc:
            st.error(f"Could not use this CSV: {exc}")
else:
    rainfall_mm = st.number_input("Kharif-season rainfall (mm)", min_value=0.0, value=float(optimum), step=25.0)

st.subheader("Field inputs")
left, right = st.columns(2)
with left:
    area = st.number_input("Cotton cultivation area (hectares)", min_value=0.1, value=1.0, step=0.5)
with right:
    irrigation = st.number_input("Supplemental irrigation during the season (mm)", min_value=0.0, value=0.0, step=25.0)

if rainfall_mm is None:
    st.button("Estimate cotton yield", type="primary", use_container_width=True, disabled=True)
    if rainfall_source == "Upload rainfall CSV" and uploaded is None:
        st.info("Upload a rainfall CSV or choose manual entry to continue.")
elif st.button("Estimate cotton yield", type="primary", use_container_width=True):
    profile = CottonProfile(
        potential_yield_t_ha=potential,
        optimal_rainfall_mm=optimum,
        adequate_irrigation_mm=adequate_irrigation,
    )
    result = estimate_cotton_yield(area, rainfall_mm, irrigation, profile)
    st.subheader("Estimated cotton harvest")
    a, b = st.columns(2)
    a.metric("Estimated yield per hectare", f"{result['yield_per_ha_t']:.2f} t/ha")
    b.metric("Estimated total yield", f"{result['total_yield_t']:.2f} tonnes")
    st.progress(min(result["yield_fraction"], 1.0), text=f"{result['yield_fraction']:.0%} of configured cotton yield potential")
    with st.expander("How the fuzzy controller reached this estimate"):
        if rainfall_summary:
            st.write(f"Rainfall input: {rainfall_summary}.")
        st.write("Rainfall memberships", {key: f"{value:.2f}" for key, value in result["rainfall_memberships"].items()})
        st.write("Irrigation memberships", {key: f"{value:.2f}" for key, value in result["irrigation_memberships"].items()})
        st.caption("The rule base lets irrigation offset low rainfall and reduces the estimate when rainfall and irrigation are both very high. It does not model soil, temperature, cotton variety, pests, or location-specific crop response.")

st.divider()
st.caption("Run with:  python -m pip install -r requirements.txt  ·  python -m streamlit run app.py")
